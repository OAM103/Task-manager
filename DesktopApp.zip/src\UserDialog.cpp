#include "UserDialog.hpp"

#include <QDialogButtonBox>
#include <QFormLayout>
#include <QLineEdit>
#include <QSpinBox>
#include <QVBoxLayout>

UserDialog::UserDialog(QWidget *parent)
    : QDialog(parent)
{
    setWindowTitle("Данные пользователя");
    setMinimumWidth(300);

    nameInput = new QLineEdit(this);
    nameInput->setPlaceholderText("Введите имя");

    ageInput = new QSpinBox(this);
    ageInput->setRange(1, 120);

    auto *formLayout = new QFormLayout;
    formLayout->addRow("Имя:", nameInput);
    formLayout->addRow("Возраст:", ageInput);

    auto *buttons = new QDialogButtonBox(
        QDialogButtonBox::Ok | QDialogButtonBox::Cancel,
        this
    );

    auto *layout = new QVBoxLayout(this);
    layout->addLayout(formLayout);
    layout->addWidget(buttons);

    QObject::connect(
        buttons,
        &QDialogButtonBox::accepted,
        this,
        &QDialog::accept
    );

    QObject::connect(
        buttons,
        &QDialogButtonBox::rejected,
        this,
        &QDialog::reject
    );
}

QString UserDialog::name() const
{
    return nameInput->text().trimmed();
}

int UserDialog::age() const
{
    return ageInput->value();
}