#include "ReminderManager.hpp"

#include <QDateTime>

ReminderManager::ReminderManager(
    QObject *parent
)
    : QObject(parent)
{
    timer.setInterval(
        1000
    );

    connect(
        &timer,
        &QTimer::timeout,
        this,
        &ReminderManager::checkTasks
    );

    timer.start();
}

void ReminderManager::setTasks(
    const QList<Task> &newTasks
)
{
    tasks =
        newTasks;

    QSet<int> existingIds;

    for (const Task &task : tasks)
    {
        existingIds.insert(
            task.id
        );
    }

    QSet<int> cleanedNotifications;

    for (
        const int id :
        notifiedTaskIds
    )
    {
        if (
            existingIds.contains(id)
        )
        {
            cleanedNotifications.insert(
                id
            );
        }
    }

    notifiedTaskIds =
        cleanedNotifications;

    checkTasks();
}

void ReminderManager::checkTasks()
{
    const QDateTime now =
        QDateTime::currentDateTime();

    for (const Task &task : tasks)
    {
        if (task.completed)
        {
            continue;
        }

        if (!task.dueDateTime.isValid())
        {
            continue;
        }

        if (
            task.dueDateTime > now
        )
        {
            continue;
        }

        if (
            notifiedTaskIds.contains(
                task.id
            )
        )
        {
            continue;
        }

        notifiedTaskIds.insert(
            task.id
        );

        emit reminderTriggered(
            task
        );
    }
}