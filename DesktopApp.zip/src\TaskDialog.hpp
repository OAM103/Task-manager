#pragma once

#include <QDialog>

#include "Task.hpp"

class QComboBox;
class QDateTimeEdit;
class QLineEdit;
class QTextEdit;

class TaskDialog : public QDialog
{
public:
    explicit TaskDialog(
        QWidget *parent = nullptr
    );

    void setTask(
        const Task &task
    );

    Task getTask() const;

private:
    void applyQuickDeadline(
        int index
    );

    QLineEdit *titleInput;
    QTextEdit *descriptionInput;

    QComboBox *priorityInput;
    QComboBox *quickDeadlineInput;

    QDateTimeEdit *dueDateTimeInput;
};