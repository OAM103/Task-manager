#pragma once

#include <QObject>
#include <QSet>
#include <QTimer>
#include <QList>

#include "Task.hpp"

class ReminderManager : public QObject
{
    Q_OBJECT

public:
    explicit ReminderManager(
        QObject *parent = nullptr
    );

    void setTasks(
        const QList<Task> &tasks
    );

signals:
    void reminderTriggered(
        const Task &task
    );

private slots:
    void checkTasks();

private:
    QList<Task> tasks;

    QSet<int> notifiedTaskIds;

    QTimer timer;
};