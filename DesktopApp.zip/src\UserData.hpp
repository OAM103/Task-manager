#pragma once

#include <QString>

class UserData
{
public:
    UserData();

    void setName(const QString &name);
    void setAge(int age);

    QString name() const;
    int age() const;

    bool isValid() const;

private:
    QString m_name;
    int m_age;
};