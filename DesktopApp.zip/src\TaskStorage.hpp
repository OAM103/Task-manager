#pragma once

#include <QList>
#include <QString>

#include "Task.hpp"

class TaskStorage
{
public:
    explicit TaskStorage(
        const QString &filePath
    );

    bool save(
        const QList<Task> &tasks
    ) const;

    bool load(
        QList<Task> &tasks
    ) const;

private:
    QString filePath;
};