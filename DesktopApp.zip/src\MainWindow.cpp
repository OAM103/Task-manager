#include "MainWindow.hpp"

#include "TaskDialog.hpp"
#include "TaskDelegate.hpp"

#include <QAction>
#include <QApplication>
#include <QCloseEvent>
#include <QComboBox>
#include <QDir>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QListView>
#include <QMenu>
#include <QPushButton>
#include <QStandardPaths>
#include <QSystemTrayIcon>
#include <QVBoxLayout>

MainWindow::MainWindow(
    QWidget *parent
)
    : QWidget(parent),
      storage(
          QStandardPaths::writableLocation(
              QStandardPaths::AppDataLocation
          ) + "/tasks.json"
      ),
      taskModel(
          new TaskModel(this)
      ),
      proxyModel(
          new TaskFilterProxyModel(this)
      ),
      reminderManager(
          new ReminderManager(this)
      ),
      trayIcon(
          new QSystemTrayIcon(this)
      ),
      trayMenu(
          new QMenu(this)
      )
{
    setWindowTitle(
        "Task Manager"
    );

    setMinimumSize(
        800,
        550
    );

    setWindowIcon(
        QIcon(":/app.svg")
    );

    searchInput =
        new QLineEdit(this);

    searchInput->setPlaceholderText(
        "Поиск по названию и описанию..."
    );

    statusFilter =
        new QComboBox(this);

    statusFilter->addItem("Все");
    statusFilter->addItem("Активные");
    statusFilter->addItem("Выполненные");

    sortMode =
        new QComboBox(this);

    sortMode->addItem(
        "Без сортировки"
    );

    sortMode->addItem(
        "По сроку"
    );

    sortMode->addItem(
        "По приоритету"
    );

    taskList =
        new QListView(this);

    proxyModel->setSourceModel(
        taskModel
    );

    proxyModel->setSortRole(
        TaskModel::DueDateRole
    );

    taskList->setModel(
        proxyModel
    );

    taskList->setItemDelegate(
        new TaskDelegate(taskList)
    );

    taskList->setSpacing(4);

    taskList->setSelectionMode(
        QAbstractItemView::SingleSelection
    );

    addButton =
        new QPushButton(
            "Добавить",
            this
        );

    editButton =
        new QPushButton(
            "Редактировать",
            this
        );

    completeButton =
        new QPushButton(
            "Выполнить",
            this
        );

    deleteButton =
        new QPushButton(
            "Удалить",
            this
        );

    resetButton =
        new QPushButton(
            "Сбросить",
            this
        );

    statisticsLabel =
        new QLabel(this);

    auto *filterLayout =
        new QHBoxLayout;

    filterLayout->addWidget(
        searchInput
    );

    filterLayout->addWidget(
        statusFilter
    );

    filterLayout->addWidget(
        sortMode
    );

    filterLayout->addWidget(
        resetButton
    );

    auto *buttonLayout =
        new QHBoxLayout;

    buttonLayout->addWidget(
        addButton
    );

    buttonLayout->addWidget(
        editButton
    );

    buttonLayout->addWidget(
        completeButton
    );

    buttonLayout->addWidget(
        deleteButton
    );

    auto *layout =
        new QVBoxLayout(this);

    layout->addLayout(
        filterLayout
    );

    layout->addWidget(
        taskList
    );

    layout->addLayout(
        buttonLayout
    );

    layout->addWidget(
        statisticsLabel
    );

    connect(
        addButton,
        &QPushButton::clicked,
        this,
        &MainWindow::addTask
    );

    connect(
        editButton,
        &QPushButton::clicked,
        this,
        &MainWindow::editTask
    );

    connect(
        deleteButton,
        &QPushButton::clicked,
        this,
        &MainWindow::deleteTask
    );

    connect(
        completeButton,
        &QPushButton::clicked,
        this,
        &MainWindow::toggleTaskCompleted
    );

    connect(
        resetButton,
        &QPushButton::clicked,
        this,
        &MainWindow::resetFilters
    );

    connect(
        searchInput,
        &QLineEdit::textChanged,
        this,
        [this](const QString &text)
        {
            proxyModel->setSearchText(
                text
            );

            refreshTaskList();
        }
    );

    connect(
        statusFilter,
        &QComboBox::currentIndexChanged,
        this,
        [this](int index)
        {
            switch (index)
            {
                case 1:
                    proxyModel->setStatusFilter(
                        TaskFilterProxyModel::StatusFilter::Active
                    );
                    break;

                case 2:
                    proxyModel->setStatusFilter(
                        TaskFilterProxyModel::StatusFilter::Completed
                    );
                    break;

                default:
                    proxyModel->setStatusFilter(
                        TaskFilterProxyModel::StatusFilter::All
                    );
                    break;
            }

            refreshTaskList();
        }
    );

    connect(
        sortMode,
        &QComboBox::currentIndexChanged,
        this,
        [this]()
        {
            refreshTaskList();
        }
    );

    connect(
        taskList,
        &QListView::doubleClicked,
        this,
        [this](const QModelIndex &)
        {
            editTask();
        }
    );

    connect(
        reminderManager,
        &ReminderManager::reminderTriggered,
        this,
        &MainWindow::showReminder
    );

    overdueRefreshTimer.setInterval(
        1000
    );

    connect(
        &overdueRefreshTimer,
        &QTimer::timeout,
        this,
        &MainWindow::updateOverdueTasks
    );

    overdueRefreshTimer.start();

    QDir().mkpath(
        QStandardPaths::writableLocation(
            QStandardPaths::AppDataLocation
        )
    );

    if (!storage.load(tasks))
    {
        tasks.clear();
    }

    for (const Task &task : tasks)
    {
        if (
            task.id >= nextTaskId
        )
        {
            nextTaskId =
                task.id + 1;
        }
    }

    taskModel->setTasks(
        tasks
    );

    reminderManager->setTasks(
        tasks
    );

    setupTrayIcon();

    refreshTaskList();
}

MainWindow::~MainWindow()
{
    saveTasks();
}

void MainWindow::updateOverdueTasks()
{
    if (tasks.isEmpty())
    {
        return;
    }

    for (
        int row = 0;
        row < tasks.size();
        ++row
    )
    {
        taskModel->updateTask(
            row
        );
    }

    refreshTaskList();
}

void MainWindow::setupTrayIcon()
{
    trayIcon->setIcon(
        QIcon(":/app.svg")
    );

    trayIcon->setToolTip(
        "Task Manager"
    );

    QAction *showAction =
        trayMenu->addAction(
            "Открыть Task Manager"
        );

    QAction *hideAction =
        trayMenu->addAction(
            "Скрыть окно"
        );

    trayMenu->addSeparator();

    QAction *quitAction =
        trayMenu->addAction(
            "Выход"
        );

    connect(
        showAction,
        &QAction::triggered,
        this,
        &MainWindow::showFromTray
    );

    connect(
        hideAction,
        &QAction::triggered,
        this,
        &MainWindow::hideToTray
    );

    connect(
        quitAction,
        &QAction::triggered,
        this,
        [this]()
        {
            reallyQuit = true;

            qApp->quit();
        }
    );

    trayIcon->setContextMenu(
        trayMenu
    );

    connect(
        trayIcon,
        &QSystemTrayIcon::activated,
        this,
        [this](
            QSystemTrayIcon::ActivationReason reason
        )
        {
            if (
                reason ==
                QSystemTrayIcon::Trigger
            )
            {
                if (isVisible())
                {
                    hideToTray();
                }
                else
                {
                    showFromTray();
                }
            }
        }
    );

    trayIcon->show();
}

void MainWindow::showFromTray()
{
    show();

    showNormal();

    raise();

    activateWindow();
}

void MainWindow::hideToTray()
{
    hide();
}

void MainWindow::closeEvent(
    QCloseEvent *event
)
{
    if (reallyQuit)
    {
        event->accept();
        return;
    }

    hide();

    event->ignore();
}

void MainWindow::showReminder(
    const Task &task
)
{
    if (!trayIcon->isVisible())
    {
        return;
    }

    trayIcon->showMessage(
        "Задача просрочена",
        task.title,
        QSystemTrayIcon::Warning,
        10000
    );
}

void MainWindow::refreshTaskList()
{
    switch (
        sortMode->currentIndex()
    )
    {
        case 1:
            proxyModel->setSortRole(
                TaskModel::DueDateRole
            );

            proxyModel->sort(
                0,
                Qt::AscendingOrder
            );

            break;

        case 2:
            proxyModel->setSortRole(
                TaskModel::PriorityRole
            );

            proxyModel->sort(
                0,
                Qt::DescendingOrder
            );

            break;

        default:
            break;
    }

    int completedCount = 0;

    for (const Task &task : tasks)
    {
        if (task.completed)
        {
            ++completedCount;
        }
    }

    statisticsLabel->setText(
        QString(
            "Всего: %1 | "
            "Выполнено: %2 | "
            "Осталось: %3 | "
            "Показано: %4"
        )
        .arg(tasks.size())
        .arg(completedCount)
        .arg(
            tasks.size() -
            completedCount
        )
        .arg(
            proxyModel->rowCount()
        )
    );
}

void MainWindow::addTask()
{
    TaskDialog dialog(this);

    if (
        dialog.exec() !=
        QDialog::Accepted
    )
    {
        return;
    }

    Task task =
        dialog.getTask();

    task.id =
        nextTaskId++;

    tasks.append(
        task
    );

    taskModel->setTasks(
        tasks
    );

    reminderManager->setTasks(
        tasks
    );

    saveTasks();

    refreshTaskList();
}

void MainWindow::editTask()
{
    const QModelIndex proxyIndex =
        taskList->currentIndex();

    if (!proxyIndex.isValid())
    {
        return;
    }

    const QModelIndex sourceIndex =
        proxyModel->mapToSource(
            proxyIndex
        );

    Task *task =
        taskModel->getTask(
            sourceIndex.row()
        );

    if (!task)
    {
        return;
    }

    TaskDialog dialog(this);

    dialog.setTask(
        *task
    );

    if (
        dialog.exec() !=
        QDialog::Accepted
    )
    {
        return;
    }

    const int id =
        task->id;

    const bool completed =
        task->completed;

    *task =
        dialog.getTask();

    task->id =
        id;

    task->completed =
        completed;

    taskModel->updateTask(
        sourceIndex.row()
    );

    tasks =
        taskModel->getTasks();

    reminderManager->setTasks(
        tasks
    );

    saveTasks();

    refreshTaskList();
}

void MainWindow::deleteTask()
{
    const QModelIndex proxyIndex =
        taskList->currentIndex();

    if (!proxyIndex.isValid())
    {
        return;
    }

    const QModelIndex sourceIndex =
        proxyModel->mapToSource(
            proxyIndex
        );

    taskModel->removeTask(
        sourceIndex.row()
    );

    tasks =
        taskModel->getTasks();

    reminderManager->setTasks(
        tasks
    );

    saveTasks();

    refreshTaskList();
}

void MainWindow::toggleTaskCompleted()
{
    const QModelIndex proxyIndex =
        taskList->currentIndex();

    if (!proxyIndex.isValid())
    {
        return;
    }

    const QModelIndex sourceIndex =
        proxyModel->mapToSource(
            proxyIndex
        );

    Task *task =
        taskModel->getTask(
            sourceIndex.row()
        );

    if (!task)
    {
        return;
    }

    task->completed =
        !task->completed;

    taskModel->updateTask(
        sourceIndex.row()
    );

    tasks =
        taskModel->getTasks();

    reminderManager->setTasks(
        tasks
    );

    saveTasks();

    refreshTaskList();
}

Task *MainWindow::findTaskById(
    int id
)
{
    for (Task &task : tasks)
    {
        if (task.id == id)
        {
            return &task;
        }
    }

    return nullptr;
}

void MainWindow::resetFilters()
{
    searchInput->clear();

    statusFilter->setCurrentIndex(
        0
    );

    sortMode->setCurrentIndex(
        0
    );

    proxyModel->setSearchText(
        ""
    );

    proxyModel->setStatusFilter(
        TaskFilterProxyModel::StatusFilter::All
    );

    refreshTaskList();
}

void MainWindow::saveTasks()
{
    storage.save(
        tasks
    );
}