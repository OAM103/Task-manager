#pragma once

#include <QDateTime>
#include <QString>

enum class TaskPriority
{
    Low,
    Normal,
    High
};

struct Task
{
    int id = 0;

    QString title;
    QString description;

    TaskPriority priority =
        TaskPriority::Normal;

    QDateTime dueDateTime;

    bool completed = false;
};