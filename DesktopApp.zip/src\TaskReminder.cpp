#include "TaskReminder.hpp"

#include <QDateTime>

TaskReminder::TaskReminder(QObject *parent)
    : QObject(parent)
{
    timer.setInterval(1000);

    connect(
        &timer,
        &QTimer::timeout,
        this,
        &TaskReminder::checkTasks
    );

    timer.start();
}

void TaskReminder::setTasks(
    const QList<Task> *newTasks
)
{
    tasks = newTasks;
}

void TaskReminder::reset()
{
    notifiedTaskIds.clear();
}

void TaskReminder::checkTasks()
{
    if (!tasks)
    {
        return;
    }

    const QDateTime now =
        QDateTime::currentDateTime();

    for (const Task &task : *tasks)
    {
        if (task.completed)
        {
            continue;
        }

        if (!task.dueDateTime.isValid())
        {
            continue;
        }

        if (notifiedTaskIds.contains(task.id))
        {
            continue;
        }

        if (task.dueDateTime <= now)
        {
            notifiedTaskIds.insert(task.id);

            emit taskDue(task);
        }
    }
}