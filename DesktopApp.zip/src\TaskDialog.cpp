#include "TaskDialog.hpp"

#include <QComboBox>
#include <QDateTimeEdit>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QLineEdit>
#include <QPushButton>
#include <QTextEdit>
#include <QVBoxLayout>

TaskDialog::TaskDialog(
    QWidget *parent
)
    : QDialog(parent)
{
    setWindowTitle(
        "Новая задача"
    );

    setMinimumWidth(500);

    titleInput =
        new QLineEdit(this);

    titleInput->setPlaceholderText(
        "Название задачи"
    );

    descriptionInput =
        new QTextEdit(this);

    descriptionInput->setPlaceholderText(
        "Описание задачи"
    );

    descriptionInput->setMinimumHeight(
        110
    );

    priorityInput =
        new QComboBox(this);

    priorityInput->addItem(
        "Низкий"
    );

    priorityInput->addItem(
        "Обычный"
    );

    priorityInput->addItem(
        "Высокий"
    );

    quickDeadlineInput =
        new QComboBox(this);

    quickDeadlineInput->addItem(
        "Выбрать срок..."
    );

    quickDeadlineInput->addItem(
        "Через 15 минут"
    );

    quickDeadlineInput->addItem(
        "Через 30 минут"
    );

    quickDeadlineInput->addItem(
        "Через 1 час"
    );

    quickDeadlineInput->addItem(
        "Через 2 часа"
    );

    quickDeadlineInput->addItem(
        "Через день"
    );

    quickDeadlineInput->addItem(
        "Завтра в это же время"
    );

    quickDeadlineInput->addItem(
        "Через неделю"
    );

    dueDateTimeInput =
        new QDateTimeEdit(
            QDateTime::currentDateTime()
                .addSecs(3600),
            this
        );

    dueDateTimeInput->setCalendarPopup(
        true
    );

    dueDateTimeInput->setDisplayFormat(
        "dd.MM.yyyy HH:mm"
    );

    dueDateTimeInput->setMinimumWidth(
        190
    );

    auto *formLayout =
        new QFormLayout;

    formLayout->setLabelAlignment(
        Qt::AlignRight
    );

    formLayout->addRow(
        "Название:",
        titleInput
    );

    formLayout->addRow(
        "Описание:",
        descriptionInput
    );

    formLayout->addRow(
        "Приоритет:",
        priorityInput
    );

    formLayout->addRow(
        "Быстрый срок:",
        quickDeadlineInput
    );

    formLayout->addRow(
        "Точный срок:",
        dueDateTimeInput
    );

    auto *buttons =
        new QDialogButtonBox(
            QDialogButtonBox::Ok |
            QDialogButtonBox::Cancel,
            this
        );

    buttons->button(
        QDialogButtonBox::Ok
    )->setText(
        "Сохранить"
    );

    buttons->button(
        QDialogButtonBox::Cancel
    )->setText(
        "Отмена"
    );

    auto *layout =
        new QVBoxLayout(this);

    layout->addLayout(
        formLayout
    );

    layout->addWidget(
        buttons
    );

    connect(
        quickDeadlineInput,
        &QComboBox::currentIndexChanged,
        this,
        [this](int index)
        {
            applyQuickDeadline(index);
        }
    );

    connect(
        buttons,
        &QDialogButtonBox::accepted,
        this,
        [this]()
        {
            if (
                titleInput
                    ->text()
                    .trimmed()
                    .isEmpty()
            )
            {
                titleInput->setFocus();
                return;
            }

            if (
                dueDateTimeInput
                    ->dateTime()
                    .isValid() == false
            )
            {
                dueDateTimeInput->setFocus();
                return;
            }

            accept();
        }
    );

    connect(
        buttons,
        &QDialogButtonBox::rejected,
        this,
        &QDialog::reject
    );
}

void TaskDialog::applyQuickDeadline(
    int index
)
{
    if (index == 0)
    {
        return;
    }

    const QDateTime now =
        QDateTime::currentDateTime();

    QDateTime deadline;

    switch (index)
    {
        case 1:
            deadline =
                now.addSecs(
                    15 * 60
                );
            break;

        case 2:
            deadline =
                now.addSecs(
                    30 * 60
                );
            break;

        case 3:
            deadline =
                now.addSecs(
                    60 * 60
                );
            break;

        case 4:
            deadline =
                now.addSecs(
                    2 * 60 * 60
                );
            break;

        case 5:
            deadline =
                now.addDays(1);
            break;

        case 6:
            deadline =
                now.addDays(1);
            break;

        case 7:
            deadline =
                now.addDays(7);
            break;

        default:
            return;
    }

    dueDateTimeInput->setDateTime(
        deadline
    );
}

void TaskDialog::setTask(
    const Task &task
)
{
    titleInput->setText(
        task.title
    );

    descriptionInput->setPlainText(
        task.description
    );

    switch (task.priority)
    {
        case TaskPriority::Low:
            priorityInput->setCurrentIndex(
                0
            );
            break;

        case TaskPriority::Normal:
            priorityInput->setCurrentIndex(
                1
            );
            break;

        case TaskPriority::High:
            priorityInput->setCurrentIndex(
                2
            );
            break;
    }

    if (
        task.dueDateTime.isValid()
    )
    {
        dueDateTimeInput->setDateTime(
            task.dueDateTime
        );
    }

    quickDeadlineInput->setCurrentIndex(
        0
    );

    setWindowTitle(
        "Редактирование задачи"
    );
}

Task TaskDialog::getTask() const
{
    Task task;

    task.title =
        titleInput
            ->text()
            .trimmed();

    task.description =
        descriptionInput
            ->toPlainText()
            .trimmed();

    switch (
        priorityInput->currentIndex()
    )
    {
        case 0:
            task.priority =
                TaskPriority::Low;
            break;

        case 1:
            task.priority =
                TaskPriority::Normal;
            break;

        case 2:
            task.priority =
                TaskPriority::High;
            break;
    }

    task.dueDateTime =
        dueDateTimeInput->dateTime();

    return task;
}