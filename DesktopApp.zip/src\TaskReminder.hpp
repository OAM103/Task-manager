#pragma once

#include <QSet>
#include <QTimer>
#include <QObject>

#include "Task.hpp"

class TaskReminder : public QObject
{
    Q_OBJECT

public:
    explicit TaskReminder(QObject *parent = nullptr);

    void setTasks(const QList<Task> *tasks);

    void reset();

signals:
    void taskDue(const Task &task);

private:
    void checkTasks();

    const QList<Task> *tasks = nullptr;

    QTimer timer;

    QSet<int> notifiedTaskIds;
};