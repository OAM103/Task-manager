#pragma once

#include <QList>
#include <QTimer>
#include <QWidget>

#include "Task.hpp"
#include "TaskModel.hpp"
#include "TaskStorage.hpp"
#include "TaskFilterProxyModel.hpp"
#include "ReminderManager.hpp"

class QLabel;
class QLineEdit;
class QListView;
class QPushButton;
class QComboBox;
class QSystemTrayIcon;
class QMenu;

class MainWindow : public QWidget
{
public:
    explicit MainWindow(
        QWidget *parent = nullptr
    );

    ~MainWindow();

protected:
    void closeEvent(
        QCloseEvent *event
    ) override;

private:
    void addTask();
    void editTask();
    void deleteTask();
    void toggleTaskCompleted();

    void refreshTaskList();
    void resetFilters();

    void saveTasks();

    void setupTrayIcon();

    void showFromTray();
    void hideToTray();

    void showReminder(
        const Task &task
    );

    void updateOverdueTasks();

    Task *findTaskById(
        int id
    );

    QList<Task> tasks;

    int nextTaskId = 1;

    TaskStorage storage;

    TaskModel *taskModel;
    TaskFilterProxyModel *proxyModel;

    ReminderManager *reminderManager;

    QLineEdit *searchInput;
    QComboBox *statusFilter;
    QComboBox *sortMode;

    QListView *taskList;

    QPushButton *addButton;
    QPushButton *editButton;
    QPushButton *deleteButton;
    QPushButton *completeButton;
    QPushButton *resetButton;

    QLabel *statisticsLabel;

    QSystemTrayIcon *trayIcon;
    QMenu *trayMenu;

    QTimer overdueRefreshTimer;

    bool reallyQuit = false;
};