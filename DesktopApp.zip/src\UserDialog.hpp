#pragma once

#include <QDialog>

class QLineEdit;
class QSpinBox;

class UserDialog : public QDialog
{
public:
    explicit UserDialog(QWidget *parent = nullptr);

    QString name() const;
    int age() const;

private:
    QLineEdit *nameInput;
    QSpinBox *ageInput;
};