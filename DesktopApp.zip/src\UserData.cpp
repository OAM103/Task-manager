#include "UserData.hpp"

UserData::UserData()
    : m_age(0)
{
}

void UserData::setName(const QString &name)
{
    m_name = name.trimmed();
}

void UserData::setAge(int age)
{
    m_age = age;
}

QString UserData::name() const
{
    return m_name;
}

int UserData::age() const
{
    return m_age;
}

bool UserData::isValid() const
{
    return !m_name.isEmpty() && m_age > 0;
}