#pragma once

#include <QAbstractListModel>
#include <QList>

#include "Task.hpp"

class TaskModel : public QAbstractListModel
{
public:
    enum Roles
    {
        TaskIdRole = Qt::UserRole + 1,
        CompletedRole,
        PriorityRole,
        DueDateRole,
        OverdueRole
    };

    explicit TaskModel(
        QObject *parent = nullptr
    );

    int rowCount(
        const QModelIndex &parent = QModelIndex()
    ) const override;

    QVariant data(
        const QModelIndex &index,
        int role = Qt::DisplayRole
    ) const override;

    Qt::ItemFlags flags(
        const QModelIndex &index
    ) const override;

    void setTasks(
        const QList<Task> &newTasks
    );

    const QList<Task> &getTasks() const;

    Task *getTask(
        int row
    );

    void updateTask(
        int row
    );

    void addTask(
        const Task &task
    );

    void removeTask(
        int row
    );

private:
    QList<Task> tasks;
};