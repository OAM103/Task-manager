#include <QApplication>
#include <QFile>
#include <QIcon>

#include "MainWindow.hpp"

int main(int argc, char *argv[])
{
    QApplication application(argc, argv);

    application.setApplicationName("Task Manager");
    application.setApplicationDisplayName("Task Manager");
    application.setOrganizationName("TaskManager");

    application.setWindowIcon(
        QIcon(":/app.svg")
    );

    QFile styleFile(":/style.qss");

    if (styleFile.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        application.setStyleSheet(
            QString::fromUtf8(styleFile.readAll())
        );
    }

    MainWindow window;

    window.show();

    return application.exec();
}