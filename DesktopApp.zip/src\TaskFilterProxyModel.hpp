#pragma once

#include <QSortFilterProxyModel>

class TaskFilterProxyModel
    : public QSortFilterProxyModel
{
public:
    enum class StatusFilter
    {
        All,
        Active,
        Completed
    };

    explicit TaskFilterProxyModel(
        QObject *parent = nullptr
    );

    void setSearchText(
        const QString &text
    );

    void setStatusFilter(
        StatusFilter filter
    );

protected:
    bool filterAcceptsRow(
        int sourceRow,
        const QModelIndex &sourceParent
    ) const override;

private:
    QString searchText;
    StatusFilter statusFilter =
        StatusFilter::All;
};