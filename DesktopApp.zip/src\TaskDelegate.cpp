#include "TaskDelegate.hpp"

#include "TaskModel.hpp"

#include <QApplication>
#include <QPainter>
#include <QStyle>

TaskDelegate::TaskDelegate(
    QObject *parent
)
    : QStyledItemDelegate(parent)
{
}

void TaskDelegate::paint(
    QPainter *painter,
    const QStyleOptionViewItem &option,
    const QModelIndex &index
) const
{
    painter->save();

    const QRect rect =
        option.rect.adjusted(
            6,
            4,
            -6,
            -4
        );

    const bool selected =
        option.state &
        QStyle::State_Selected;

    const bool completed =
        index.data(
            TaskModel::CompletedRole
        ).toBool();

    const int priority =
        index.data(
            TaskModel::PriorityRole
        ).toInt();

    if (selected)
    {
        painter->setBrush(
            QColor("#e8edff")
        );
    }
    else
    {
        painter->setBrush(
            QColor("#ffffff")
        );
    }

    painter->setPen(Qt::NoPen);

    painter->drawRoundedRect(
        rect,
        12,
        12
    );

    QColor priorityColor;

    switch (priority)
    {
        case static_cast<int>(
            TaskPriority::Low
        ):
            priorityColor =
                QColor("#22c55e");
            break;

        case static_cast<int>(
            TaskPriority::High
        ):
            priorityColor =
                QColor("#ef4444");
            break;

        default:
            priorityColor =
                QColor("#6366f1");
            break;
    }

    QRect priorityRect(
        rect.left() + 12,
        rect.top() + 12,
        5,
        rect.height() - 24
    );

    painter->setBrush(
        priorityColor
    );

    painter->drawRoundedRect(
        priorityRect,
        2,
        2
    );

    const QString title =
        index.data(
            Qt::DisplayRole
        ).toString()
        .section('\n', 0, 0)
        .mid(3);

    const QString details =
        index.data(
            Qt::DisplayRole
        ).toString()
        .section('\n', 1, 1);

    const QString description =
        index.data(
            Qt::DisplayRole
        ).toString()
        .section('\n', 2);

    QFont titleFont =
        option.font;

    titleFont.setBold(true);
    titleFont.setPointSize(
        titleFont.pointSize() + 1
    );

    if (completed)
    {
        titleFont.setStrikeOut(true);
    }

    painter->setFont(titleFont);

    painter->setPen(
        completed
            ? QColor("#9ca3af")
            : QColor("#20242c")
    );

    QRect titleRect(
        rect.left() + 30,
        rect.top() + 10,
        rect.width() - 42,
        25
    );

    painter->drawText(
        titleRect,
        Qt::AlignLeft |
        Qt::AlignVCenter,
        title
    );

    QFont detailsFont =
        option.font;

    detailsFont.setPointSize(
        detailsFont.pointSize() - 1
    );

    painter->setFont(detailsFont);

    painter->setPen(
        QColor("#6b7280")
    );

    QRect detailsRect(
        rect.left() + 30,
        rect.top() + 37,
        rect.width() - 42,
        22
    );

    painter->drawText(
        detailsRect,
        Qt::AlignLeft |
        Qt::AlignVCenter,
        details
    );

    if (!description.isEmpty())
    {
        painter->setPen(
            QColor("#9ca3af")
        );

        QRect descriptionRect(
            rect.left() + 30,
            rect.top() + 61,
            rect.width() - 42,
            25
        );

        painter->drawText(
            descriptionRect,
            Qt::AlignLeft |
            Qt::AlignVCenter,
            description
        );
    }

    painter->restore();
}

QSize TaskDelegate::sizeHint(
    const QStyleOptionViewItem &option,
    const QModelIndex &index
) const
{
    Q_UNUSED(option);

    const QString description =
        index.data(
            Qt::DisplayRole
        ).toString()
        .section('\n', 2);

    if (description.isEmpty())
    {
        return QSize(
            0,
            76
        );
    }

    return QSize(
        0,
        96
    );
}